A clock app made in Android Studio
